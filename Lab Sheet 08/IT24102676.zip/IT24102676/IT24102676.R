
setwd("C:\\Users\\Admin\\Desktop\\IT24102676")


data <- read.table("Data - Lab 8.txt", header = TRUE)
fix(data)
attach(data)


pop_mean <- mean(Nicotine)
pop_sd <- sd(Nicotine)

cat("1. Population Statistics:\n")
cat("Population Mean:", pop_mean, "\n")
cat("Population Standard Deviation:", pop_sd, "\n\n")


samples <- matrix(nrow = 6, ncol = 25)
sample_means <- numeric(25)
sample_sds <- numeric(25)

for (i in 1:25) {
  s <- sample(Nicotine, 6, replace = TRUE)
  samples[, i] <- s
  sample_means[i] <- mean(s)
  sample_sds[i] <- sd(s)
}

cat("2. Sample Statistics for 25 samples:\n")
for (i in 1:25) {
  cat("Sample", i, "- Mean:", round(sample_means[i], 4), 
      "SD:", round(sample_sds[i], 4), "\n")
}
cat("\n")


mean_of_means <- mean(sample_means)
sd_of_means <- sd(sample_means)

cat("3. Statistics of Sample Means:\n")
cat("Mean of Sample Means:", mean_of_means, "\n")
cat("Standard Deviation of Sample Means:", sd_of_means, "\n\n")


theoretical_sd_of_means <- pop_sd / sqrt(6)

cat("4. Comparison:\n")
cat("Population Mean (μ):", pop_mean, "\n")
cat("Mean of Sample Means (x̄):", mean_of_means, "\n")
cat("Theoretical SD of Sample Means (σ/√n =", pop_sd, "/√6):", theoretical_sd_of_means, "\n")
cat("Actual SD of Sample Means:", sd_of_means, "\n")


cat("\n5. Relationship:\n")
cat("The mean of sample means is approximately equal to the population mean.\n")
cat("The standard deviation of sample means is approximately equal to σ/√n.\n")
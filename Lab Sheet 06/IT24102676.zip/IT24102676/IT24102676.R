setwd("C:/Users/Admin/Desktop/IT24102676")

prob_at_least_47 <- 1 - pbinom(46, 50, 0.85, lower.tail = TRUE)
cat("Probability that at least 47 students passed:", prob_at_least_47, "\n")

prob_exactly_15 <- dpois(15, 12)
cat("Probability of exactly 15 calls:", prob_exactly_15, "\n")